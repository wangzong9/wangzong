def test_return():
    return True,False
x,y = test_return()
print(x)
print(y)