s = 'helloworld'
for i in range(0,len(s)) :
    print(i,s[i],end='\t\t')

print('\n' + '-' * 40)

for i in range(-10,0):
    print(i,s[i],end='\t')