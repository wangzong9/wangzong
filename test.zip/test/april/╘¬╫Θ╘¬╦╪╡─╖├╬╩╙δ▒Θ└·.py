for item in t:
    print(item)
#for+range()+len()
for i in range(len(t)):
    print(i,t[i])

# 使用enumerate()
for index,item in rnumerate(t):
    print(index,'-------->',item)