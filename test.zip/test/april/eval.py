s='3.14+3'
print(s,type(s))
x=eval(s)
print(x,type(x))
a=0b10
print(int(a))
a=0b00100
b=a <<2
print(int(a))
print(int(b))