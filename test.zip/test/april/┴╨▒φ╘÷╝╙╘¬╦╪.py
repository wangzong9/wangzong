lst=['hello','world','python']
print('原列表:',lst,id(lst))
lst.append('sql')
print('增加元素之后：',lst,id(lst))